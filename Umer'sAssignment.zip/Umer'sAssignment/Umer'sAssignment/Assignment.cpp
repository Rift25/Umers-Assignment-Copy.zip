#include "Assignment.h"

Assignment::Assignment(Vec3 gravitatinalAcceleration_)
{

}

Assignment::~Assignment()
{

}

bool Assignment::OnCreate()
{
	jetski = new Body(Vec3(0.0f, 0.0f, 0.0f), Vec3(0.0f, 0.0f, 0.0f), Vec3(0.0f, 0.0f, 0.0f), 200.0f);

	jetski2 = new Body(Vec3(0.0f, 0.0f, 0.0f), Vec3(0.0f, 0.0f, 0.0f), Vec3(0.0f, 0.0f, 0.0f), 400.0f);





	return true;
}

void Assignment::OnDestroy()
{
	delete jetski;
	jetski = nullptr;

	delete jetski2;
	jetski2 = nullptr;
}

void Assignment::Update(float time)
{

}
