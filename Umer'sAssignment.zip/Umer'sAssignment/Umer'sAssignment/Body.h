#include "Vec3.h"
class Body
{
public:
	Vec3 pos;
	Vec3 vel;
	Vec3 accel;
	float mass;

	Body();
	Body(Vec3 pos_, Vec3 vel_, Vec3 accel_, float mass_);
	~Body();

	void Update(const float deltaTime);
	void ApplyForce(Vec3 force);


};

