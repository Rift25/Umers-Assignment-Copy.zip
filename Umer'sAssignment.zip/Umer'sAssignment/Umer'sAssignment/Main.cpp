#include <iostream>
#include "Body.h"

void main()
{
	Body* jetski = new Body(Vec3(0.0f, 0.0f, 0.0f), Vec3(0.0f, 0.0f, 0.0f), Vec3(0.0f, 0.0f, 0.0f), 200.0f);
	float totalTime = 0.0f;

	jetski->ApplyForce(Vec3(500.0f, 0.0f, 0.0f));

	for (int i = 0; i <= 30; i++)
	{
		
		
		
		if (totalTime >= 5.0f && totalTime <10.0f)
		{
			jetski->ApplyForce(Vec3(0.0f, 0.0f, 0.0f));
		}

		if (totalTime == 10)
		{
			jetski->ApplyForce(Vec3(-625.0f, 0.0f, 0.0f));
		}

		if (jetski->vel.x < 0.0f)
		{
			jetski->vel.x = 0.0f;
			jetski->ApplyForce(Vec3(0.0f, 0.0f, 0.0f));
		}
        printf("position = %f  | velocity = %f  | acceleration = %f  | time = %f\n", jetski->pos.x, jetski->vel.x, jetski->accel.x, totalTime);
		jetski->Update(0.5);
        totalTime += 0.5;
	}

	getchar();
	delete jetski;
	jetski = nullptr;
}