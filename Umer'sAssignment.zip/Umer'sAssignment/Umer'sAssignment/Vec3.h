
struct Vec3
{
	float x, y, z;
	Vec3(float x_, float y_, float z_);

	Vec3();
	~Vec3();
};

