#ifndef ASSIGNMENT_H
#define ASSIGNMENT_H

#include "Body.h"


class Assignment
{
private:
	Body* jetski;
	Body* jetski2;

	float elapsedTime;
	Vec3 gravitationalAcceleration;


public:
	Assignment(Vec3 gravitatinalAcceleration_);
	~Assignment();
	bool OnCreate();
	void OnDestroy();
	void Update(float time);




};


#endif

